function [p1 p2 p3 p4 p5 p6 Kr Kw]=generaparametros_avion(dni)
%
% -------------AYUDA SOBRE LA GENERACION DE PARAMETROS-------------------
% Esta funcion genera automaticamente el sistema a considerar basado en el
% dni del alumno. 
% Entrada a la funcion: DNI expresado en forma de vector. P. ej.
% para el DNI 99999999, la funcion se invocar�a de la siguiente forma:
%     [p1,p2,p3,p4,p5,p6,Kr,Kw]=generaparametros_avion([9 9 9 9 9 9 9 9])
% Datos devueltos: 
% El sistema con parametros p1, p2, p3, p4, p5, p6, Kr y Kw a considerar en el trabajo

neto=1+sum(dni)/length(dni);

%%%%Parametro A.p1 entre -0.2 y -0.4 
p1=(0.2+0.2*(neto/10));

%%%%Parametro B.p2 entre 55 y 60
p2=55+(5*neto/10);

%%%Parametro C.p3 entre 0.1 y 0.4
p3=0.1+(0.3*(neto)/10);

%%Parametro D.p4 entre -0.01 y -0.02
p4=(0.01+(0.01*neto/10));

%%Parametro E.p5 entre -0.30 y -0.50
p5=(0.3+(0.2*neto/10));

%%Parametro F.p6 entre 0.01 y 0.03
p6=0.01+(0.02*neto/10);

%%Parametro G.Kr entre 0.75 y 1.5
Kr=0.75+(0.75*neto/10);

%%Parametro H.Kw entre 0.5 y 2
Kw=0.5+(1.5*neto/10);










